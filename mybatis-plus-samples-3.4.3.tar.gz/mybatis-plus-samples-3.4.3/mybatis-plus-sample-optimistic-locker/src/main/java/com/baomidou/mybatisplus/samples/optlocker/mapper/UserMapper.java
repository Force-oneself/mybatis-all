package com.baomidou.mybatisplus.samples.optlocker.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.samples.optlocker.entity.User;

public interface UserMapper extends BaseMapper<User> {

}
