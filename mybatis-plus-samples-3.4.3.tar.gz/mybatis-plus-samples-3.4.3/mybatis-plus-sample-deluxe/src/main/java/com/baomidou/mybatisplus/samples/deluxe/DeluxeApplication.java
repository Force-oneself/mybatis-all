package com.baomidou.mybatisplus.samples.deluxe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author miemie
 */
@SpringBootApplication
public class DeluxeApplication {

    public static void main(String[] args) {
        SpringApplication.run(DeluxeApplication.class, args);
    }
}
