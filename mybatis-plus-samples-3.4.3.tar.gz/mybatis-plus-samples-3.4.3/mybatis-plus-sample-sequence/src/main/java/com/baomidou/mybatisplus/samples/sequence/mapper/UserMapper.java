package com.baomidou.mybatisplus.samples.sequence.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.samples.sequence.entity.User;

public interface UserMapper extends BaseMapper<User> {

}
