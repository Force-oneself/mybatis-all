DELETE
FROM user;

INSERT INTO user (id, name)
VALUES (1, 'Jone'),
       (2, 'Jack'),
       (3, 'Tom'),
       (4, 'Sandy'),
       (5, 'Billie');