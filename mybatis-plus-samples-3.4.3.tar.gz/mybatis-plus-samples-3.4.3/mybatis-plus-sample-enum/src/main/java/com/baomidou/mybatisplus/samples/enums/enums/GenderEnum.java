package com.baomidou.mybatisplus.samples.enums.enums;

/**
 * <p>
 * </p>
 *
 * @author yuxiaobin
 * @date 2018/8/31
 */
public enum GenderEnum {
    MALE,
    FEMALE;
}
