DELETE FROM student;

INSERT INTO student (id, name, age) VALUES (1, 'Jone', 18),(2, 'Jack', 20),(3, 'Tom', 28),
(4, 'Sandy', 21),(5, 'Billie', 24);