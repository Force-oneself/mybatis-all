package com.baomidou.mybatisplus.samples.logic.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.samples.logic.entity.Common;

public interface CommonMapper extends BaseMapper<Common> {

}
