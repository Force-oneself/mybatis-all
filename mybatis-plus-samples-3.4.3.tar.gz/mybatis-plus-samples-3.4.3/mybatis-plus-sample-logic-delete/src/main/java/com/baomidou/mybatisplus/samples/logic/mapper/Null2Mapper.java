package com.baomidou.mybatisplus.samples.logic.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.samples.logic.entity.Null2;

/**
 * @author miemie
 * @since 2019-11-26
 */
public interface Null2Mapper extends BaseMapper<Null2> {

}
