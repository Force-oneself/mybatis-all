drop table if exists sample;
create table if not exists sample
(
    id   bigint,
    name varchar
);
