package com.baomidou.mybatisplus.test.autoconfigure;

import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author miemie
 * @since 2020-05-27
 */
@SpringBootApplication
public class MybatisPlusTestApplication {

}
