package com.baomidou.mybatisplus.test.h2.issues.genericid.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.test.h2.issues.genericid.entity.StringEntity;

/**
 * string mapper
 *
 * @author nieqiuqiu
 * @date 2019-12-20
 */
public interface StringEntityMapper extends BaseMapper<StringEntity> {

}
