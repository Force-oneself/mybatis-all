package com.baomidou.mybatisplus.test.h2.tenant.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.baomidou.mybatisplus.test.h2.tenant.model.Student;

public interface IStudentService extends IService<Student> {

}
