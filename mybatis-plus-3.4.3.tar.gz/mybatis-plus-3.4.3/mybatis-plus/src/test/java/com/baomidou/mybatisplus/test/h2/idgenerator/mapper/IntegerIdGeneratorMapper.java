package com.baomidou.mybatisplus.test.h2.idgenerator.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.test.h2.idgenerator.model.IntegerIdGeneratorModel;

public interface IntegerIdGeneratorMapper extends BaseMapper<IntegerIdGeneratorModel> {

}
