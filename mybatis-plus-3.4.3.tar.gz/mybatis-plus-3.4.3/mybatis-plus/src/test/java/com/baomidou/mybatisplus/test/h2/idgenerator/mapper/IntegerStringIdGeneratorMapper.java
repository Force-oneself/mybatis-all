package com.baomidou.mybatisplus.test.h2.idgenerator.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.test.h2.idgenerator.model.IntegerStringIdGeneratorModel;

public interface IntegerStringIdGeneratorMapper extends BaseMapper<IntegerStringIdGeneratorModel> {

}
