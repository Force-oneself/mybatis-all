package com.baomidou.mybatisplus.test.optimisticlocker;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @author miemie
 * @since 2020-06-24
 */
public interface EntityMapper extends BaseMapper<Entity> {
}
