package com.baomidou.mybatisplus.test.h2.fillperformance.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.baomidou.mybatisplus.test.h2.fillperformance.model.PerformanceModel;

public interface IPerformanceModelService extends IService<PerformanceModel> {

}
