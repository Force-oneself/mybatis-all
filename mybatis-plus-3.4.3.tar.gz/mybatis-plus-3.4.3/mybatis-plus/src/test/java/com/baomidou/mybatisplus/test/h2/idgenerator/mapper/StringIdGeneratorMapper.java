package com.baomidou.mybatisplus.test.h2.idgenerator.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.test.h2.idgenerator.model.StringIdGeneratorModel;

public interface StringIdGeneratorMapper extends BaseMapper<StringIdGeneratorModel> {

}
