<a name="Using_Spring_Boot"></a>
# Using Spring Boot
      
Please see the [MyBatis Spring-boot-starter](http://www.mybatis.org/spring-boot-starter/mybatis-spring-boot-autoconfigure) sub project docs for details.
